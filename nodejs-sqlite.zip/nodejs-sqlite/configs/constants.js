const env = process.env;

module.exports = {
  PORT: env.PORT || 3000,
};
